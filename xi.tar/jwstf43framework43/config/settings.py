# 我是配置文件  专门存放  项目中容易变化内容
#1 数据库链接配置
# 数据库信息配置
import os

DB_CONFIG = {"host": "127.0.0.1",
             "user": "root",
             "password": "123456",
             "database": "jwtest1",
             "port": 3306,
             "charset": "utf8"}
# 2 日志配置 声明 日志存放位置
jwproject_path=os.path.dirname(os.path.dirname(__file__))  #获取当前文件路径  获取上一层路径
jwlog_path=jwproject_path+os.sep+"log"
#定义方法 方便调用路径
def  get_log_path():
    return  jwlog_path

# 3 临时值配置
class  DynamicParam:# 类 存放动态属性  习惯
    pass# 占坑    等待上游存储