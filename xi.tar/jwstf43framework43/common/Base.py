# 准备两个工具函数～cv
# 导入json库
import json
# 导入Template类
from string import Template
# 导入re库
import re

# 根据参数匹配内容
#  根据左右边界 查找字符串中内容  存放列表中去
def find(data):       #这是一种re库    #这是一种查找需要引用的关键字的方法
    # 判断data类型是否为字典
    if isinstance(data, dict):  #这是一种判断格式，来进行判断所要传输的数据是不是dict，以此来判断真假
        # 对象格式化为str
        data = json.dumps(data)  #将字典转化为字符串格式
        # 定义正则匹配规则
        pattern = "\\${(.*?)}" #  提取
        # 按匹配进行查询，把查询的结果放到列表中返回
        return re.findall(pattern, data)    #re库查找方式，从下游找到关键字 re.findall(要找的字符穿，从哪里找) re.findall是一种re的寻找方法
# 进行参数替换
#  1被替换数据  要求 ${}    2 替换数据   键值对
# 替换原则：  ${} 中内容和键 一致发生替换
def relace(ori_data, replace_data):        #def replace(ori_data,replace_data):  这是将需要替换的数据和要被替换的数据放在一起。
    ori_data = json.dumps(ori_data)# 对象格式化为str
    s = Template(ori_data)  #让普通的字符串拥有被替换的能力
    # 使用新的字符，替换
                                                    # jworidata="今天捡到${money}钱"
                                                    # jwqian={"money":30000}
                                                    #
                                                    # # Template 让普通的字符串 拥有替换功能
                                                    # jwnew=Template(jworidata)
                                                    # tihuanjieguo=jwnew.safe_substitute(jwqian) # 发生替换  这是根据字典方式进行转换
    return s.safe_substitute(replace_data)
# 测试代码
if __name__ == '__main__':
    # 验证第一个方法
    # 查找id的数据
    red = find({"id": "${id_name}",
                "title": "xiaojiang", "alias": "${heiheihei}", "sex": None})
    print(red)
    # 验证第二个方法
    ori_data = {"authorization": "${jwtoken}"}
    replace_data = {'jwtoken': '22222222'}
    print(relace(ori_data, replace_data))

