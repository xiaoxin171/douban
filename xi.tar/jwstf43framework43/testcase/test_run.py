# 数据驱动方式跑用例
import json

import pytest
# 摆好工具类
from common import Base
from config.settings import DynamicParam
from utils.loguitl import logger
from utils.readmysql import RdTestcase
from utils.requestutil import RequestSend

jwcase_data=RdTestcase()  #工具1 负责用例相关操作
jwcase_list=jwcase_data.is_run_data("okr-api")# 用例列表  [{第一条}，{第二条}，{第三条}]  #okr-api是项目的名称
jwsend_jiekou=RequestSend()#工具2 发出接口请求
# 思路：跑用例：   利用工具1 从mysql获取所有用例  提取四要素  交给 工具2发出接口请求
class  TestApi:
    @pytest.mark.parametrize("case",jwcase_list)
    def test_run(self,case):#  7个  独立test_run
        print(case)
        # 提取用例的要素
        # 坑1  发接口带上服务器地址
        url= jwcase_data.loadConfkey('atstudy_okr','url_api')['value']+ case['url']
        method = case['method']
        # 坑2  requests 要求 headers body  字典json类型
        #    但是  来自数据库数据  字符串类型
        #  1字 符串 ===》字典    方式太多  json.loads   还可以 eval
        #  2 字典=====》字符串    str
        headers=eval(case['headers'])
        cookies=eval(case['cookies'])
        data=eval(case['request_body'])
        relation=str(case['relation'])
        title=case['title']

        # 发出接口请求得出自定义实际结果
        try:
            # 启用日志系统
            logger.info("正在执行{}用例".format(title))
            # 进行下游接口替换
            print("一博说替换之前数据:",headers)
            headers=self.correlation(headers)
            print("一博说替换之后数据:", headers)
            # 发出接口用例
            res_data=jwsend_jiekou.send(url,method,data=data,headers=headers,cookies=cookies)
            if res_data:
                if relation!=None:
                    #说明当前执行上游接口用例
                        self.set_relation(relation,res_data)
            #shouquanma=res_data["headers"]["Authorization"] 第五个test_run==>第七个
            logger.info("用例执行结果是{}".format(res_data))
        except:
            logger.error("用例执行失败，需要排查bug～")
            assert  False

        self.jwassert_response(case,res_data)
        return  res_data

# 上游接口
# 定义函数 set_relation  职责： 设置存放关联值
    def set_relation(self,relation,res_data):#res_data 实际结果
        try:
    #     1 先根据 relation 判断 是否是上游接口
            if relation: #jwtoken=Authorization
    #     2  对relation 字段的值 字符串切割split ==》列表
                jwlist=relation.split("=") #[jwtoken,Authorization]
    #       2.1 =左边   动态属性名字
                var_zuobian=jwlist[0]#jwtoken
    #       2.2 根据 =右边  到响应头中 找出关联值（shouquanma）
                var_youbian=jwlist[1]#Authorization==>shouquanma
                shouquanma=res_data.get("headers").get(var_youbian,"主人，没有获取到授权码")
    #     3 setattr(DynamicParam,2.1,2.2)  完成存放关联值~
                setattr(DynamicParam,var_zuobian,shouquanma)  #存放 属性名+属性的值
                print("志玲，为你验证是否存放成功",getattr(DynamicParam,var_zuobian,"存放授权码失败~"))
        except:
            print("主人，存放授权码失败")
#
# 定义函数 correlation  职责：为下游接口取出授权码进行替换
    def correlation(self,data):# 等待传递进来数据 {"Content-Type": "application/x-www-form-urlencoded","Authorization":"${jwtoken}"}
#    1  先根据 ${} 判断 是否是下游接口  取出${}值===》find函数实现
        res_data=Base.find(data) #  ["jwtoken"]
        if res_data:#  Python 语法：  列表中有东西 True  下游接口  列表中没有东西    False
            for i in res_data: #i  "jwtoken"  从 列表一一把数据取出来～
#    2  根据${} 的值  取出  getattr关联值
                shouquanma=getattr(DynamicParam,str(i),"没有找到授权码")
#    3  将关联值（shouquanma）替换${} 交给requests工具类 发出接口请求了~
            #被替换数据    data   {"Content-Type": "application/x-www-form-urlencoded","Authorization":"${jwtoken}"}
            # 替换数据     shouquanma 字符串aaaaaasssa==》 {"jwtoken":asasasasasasa}
                jwrepalce_dict={}
                jwrepalce_dict.update({str(i):shouquanma})  # {"jwtoken":asasasasasasa}
                genghuan=Base.relace(data,jwrepalce_dict)
                # 字符串--》字典 交给request 工具类 发出接口  1eval  2json.loads
                data=json.loads(genghuan)
        return  data

    # 结果验证方法

    # 参数1  用例  参数2 实际结果
    def jwassert_response(self, case, res_data):
        # 变量初始化为False
        is_pass = False #测试结果
        # 异常处理，捕获assert抛出的异常，不直接抛出
        try:
            ceshijieguo = str(case['expected_code']) in \
                          [str(res_data.get('body').get('msg', "没有msg键")),
                           str(res_data.get('body').get('message', "没有message键")),
                           str(res_data.get('body').get('success', "没有success键")),
                           str(res_data.get('code'))]
            assert ceshijieguo  # 语法 断言失败  跳转 except
            # 打印信息
            logger.info("用例断言成功")
            # 设置变量为True
            is_pass = True
        # 捕获异常
        except:
            # 设置变量为False
            is_pass = False
            # 打印日志
            logger.info("用例断言失败")
        # 无论是否出现异常，都执行下面内容代码
        finally:  # 不管是否执行     except 分支  都会最终执行分支
            # 把结果更新到数据库
            jwcase_data.updateResults(res_data, is_pass, str(case['id']))
            # 根据变量结果是True/False，进行断言验证，成功则通过，失败则未通过
            assert is_pass



if __name__ == '__main__':
    pytest.main(['-s','-v','test_run.py'])
