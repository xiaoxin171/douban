# 摆好工具类
import datetime

from utils.mysqlutil import MysqlUtil
mysql=MysqlUtil() #第一把工具
# 本类工具类  完成用例相关操作
class  RdTestcase:# 第二把工具
    # 1.加载XXX项目所有用例=加载所有数据
    def load_all_case(self,web):
        sql=f"select * from jwtest_case_list where web='{web}'"
        return  mysql.get_fetchall(sql)
    # 2.加载需要执行用例（执行isdel字段 为1用例）
    # 思路：
    #   1.sql方式 select * from jwtest_case_list where web='{web}' and isdel=1
    #   2. Python  加载所有用例 +筛选出  需要执行用例（isdel==1）即可（上课 配合新知识题）
    def is_run_data(self,web):
        # 1老版本 可读性+调试方便～
        # jwrun_list=[] # 用来存放 需要被执行的用例
        # for case in self.load_all_case(web):   #[{第一条用例}，{第二条用例}，{第三条用例}]
        #     if case['isdel']==1:
        #         jwrun_list.append(case)
        # return jwrun_list
        # Python 语法  列表推导式   精简  for 和if结构
        # 2 新版本 精简 可读性差
        #     格式 [3得出用例  1 for循环  2 判断条件]
        return  [case for case in self.load_all_case(web) if case['isdel']==1]

        #这是对用例进行一个筛选


    # 3.加载测试用例配置
    # 指定 XXX项目 XXX配置
    def loadConfkey(self,web,jwkey): #形式参数 接收实际采纳书
        jwsql=f"select * from jwtest_config where web='{web}' and key1='{jwkey}'"
        return mysql.get_fetchone(jwsql)

    # 4.测试结果回写功能
    # 思路：
    #   1  回写内容   response实际结果， is_pass测试结果 ,case_id 用例编号
    #   2   时间 当前时间 +构造sql语句
    #  3  使用工具1  执行 增删改语句
    # 坑:  接口结果 字典json  ==转换===》mysql 字符串存储varchar str
    def updateResults(self,response,is_pass,case_id):
        current_time=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        jwsql=f'insert into jwtest_result_record(case_id,times,response,result) ' \
              f'values ("{case_id}","{current_time}","{str(response)}","{is_pass}")'
        return  mysql.sql_execute(jwsql)

    #这是针对结果进行写入到数据库中


if __name__ == '__main__':
    jwtestRd=RdTestcase() # 类--》对象  方便自测编写功能
    print("第一个方法",jwtestRd.load_all_case('okr-api')) # 自测第一个方法

    # 自测第二个方法
    print("第二个方法",jwtestRd.is_run_data('okr-api'))

    # 自测第三个方法
    print("第三个方法", jwtestRd.loadConfkey('atstudy_okr','url_api')['value'])

    # 自测第四个方法：
    # 说明：被测项目okr-api返回数据时候 json字典格式
    print("自测第四个方法",jwtestRd.updateResults({'sucess':True,'message':'登录成功'},'True','9999'))
