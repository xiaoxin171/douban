# 导入Requests库
import json

import requests
# 导入logger对象

# 定义http请求类
class RequestSend:
    # 封装requests请求函数
    def api_run(self, url, method, data=None, headers=None, cookies=None):
        # 定义变量，获取响应结果
        res = None

        # 判断请求方法
        if method == "get":
            # 如果是get方法，则执行下面命令，发送http请求，方法为get
            res = requests.get(url, data=data, headers=headers, cookies=cookies)
        # 如果是post方法，则执行下面命令
        elif method == "post":
            # 判断headers内容，如果是json格式
            if headers == {"Content-Type": "application/json"}:
                # 发送http请求，方法为post，参数使用json=data
                res = requests.post(url, json=data, headers=headers, cookies=cookies)
            # 判断headers内容，如果是application/x-www-form-urlencoded格式
            elif headers == {"Content-Type": "application/x-www-form-urlencoded"}:
                # 发送http请求，方法为post，参数使用data=data
                res = requests.post(url, data=data, headers=headers, cookies=cookies)
        # 获取请求响应的状态码
        code = res.status_code
        # 获取请求响应的cookies
        cookies = res.cookies.get_dict() # cookies 比较特别需要转换才能拿到数据
        #获取请求响应头的headers
        headers=res.headers
        # 3拼装结果数据

        # 异常处理
        try:
            # 获取响应结果json格式
            body = res.json()
        # 捕获异常
        except:
            body = {"hi":"无数据"}
            # 定义字典
        dict1 = dict() #{}
        # 自定义参数code写入字典
        dict1['code'] = code
        # 自定义头信息封装起来
        dict1['headers']=headers
        # 自定义参数body写入字典
        dict1['body'] = body
        # 自定义参数cookies写入字典
        dict1['cookies'] = cookies

        # 返回自定义字典
        return dict1

    # 对外调用方法，**kwargs 传入的参数是dict类型
    # 静态:职责 发出接口请求   获取自定义格式实际结果
    def send(self, url, method, **kwargs):
        # 调用自定义方法
        return self.api_run(url=url, method=method, **kwargs)   #这是调用最上面的方法进行封装，直接调用这个方法即可

# 测试代码
if __name__ == '__main__':
    #动态
    # 登录 接口四要素
    url = "http://127.0.0.1:6088/api/User"
    data = {"username":"admin","password":"123"}
    method = "post"
    headers = {"Content-Type": "application/json"}
    print(str(RequestSend().send(url=url, method=method, headers=headers, data=data)))