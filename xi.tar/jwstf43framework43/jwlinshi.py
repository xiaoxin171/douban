# 属性===》所有对象都是存在的
#需求：  冠希 ---》打工---》工资属性  阿娇 ---》好好上学----》学历属性
#        不同的对象 要求不同属性
#       有些对象有 属性 有些对象没有的属性   ===》动态属性
#
#    设置动态属性   setattr(类对象，属性名字，属性的值)
#    获取动态属性   getattr(类对象，属性名字，默认值)
#      默认值： 当获取不到属性的时候 ，只是用默认值输出
import time


class  Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age

if __name__ == '__main__':
    p1=  Person("冠希",18)
    p2 = Person("阿娇", 20)
    print(p1.age,p1.name)
    print(p2.age, p2.name)

    print("生活开始了～。。。。。")
    time.sleep(3)
    setattr(p1,"gongzi",20000) #增加属性

    #print(p1.age, p1.name,p1.gongzi)
    #print(p2.age, p2.name,p2.gongzi) #风险就很高
    print(p1.age, p1.name, getattr(p1,"gongzi","无工资未进入社会"))
    print(p2.age, p2.name, getattr(p2, "gongzi", "无工资未进入社会"))#稳定
    print("嘿嘿嘿1～")
    print("嘿嘿嘿2～")



